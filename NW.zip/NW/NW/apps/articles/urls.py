from django.urls import path
from . import views

urlpatterns = [
	path('', views.home, name="home"),
	path('codenames', views.codenames, name="codenames"),
	path('plunking-pairs', views.plunkingPairs, name="plunkingPairs"),
	path('exploding-kittens', views.explodingKittens, name="exploding-kittens"),
	path('pandemic', views.pandemic, name="pandemic"),
	path('citadels', views.citadels, name="citadels"),
	path('celestia', views.celestia, name="celestia"),
	path('stupid-casual', views.stupidCasual, name="stupidCasual"),
	path('spyfall', views.spyfall, name="spyfall"),
	path('ticket-to-ride', views.TtR, name="TtR"),
]