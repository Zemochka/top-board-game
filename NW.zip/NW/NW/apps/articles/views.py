from django.shortcuts import render

def home(request):
	return render(request, 'articles/home.html')

def codenames(request):
	return render(request, 'articles/pages/codenames.html')

def plunkingPairs(request):
	return render(request, 'articles/pages/plunking-pairs.html')

def explodingKittens(request):
	return render(request, 'articles/pages/exploding-kittens.html')

def pandemic(request):
	return render(request, 'articles/pages/pandemic.html')

def citadels(request):
	return render(request, 'articles/pages/citadels.html')
	
def celestia(request):
	return render(request, 'articles/pages/celestia.html')

def TtR(request):
	return render(request, 'articles/pages/ticket-to-ride.html')

def stupidCasual(request):
	return render(request, 'articles/pages/stupid-casual.html')

def spyfall(request):
	return render(request, 'articles/pages/spyfall.html')